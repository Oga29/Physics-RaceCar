# Physics-RaceCar

## Gameplay Features



### Win and Lose conditions

The game consists on an infinite road fuymed by a seamless teleport where you have to drive your car as fast as possible in order to complete 4 laps. If you are too slow and the music ends before you complete the 4 laps, you will loose.

### Constraints
If you fall down from the race track you will be teleported back to the start postion without losing the race

### Two coefficients

There are two different coloroued rectangle paths, The orange one(Sand/Dirt) is slowing down the player. The Blue one(Ice) is speeding up the player. 

## Key Bindings
### On the ground:


Arrows - move your car:

Up - forward

Right - right

Left - left

Down - back

### On air:

Arrows - rotate your car:

Up - forward

Right - right

Left - left

Down - back

### Physics manipulation
G - Increase gravity

H - Decrease gravity 

M - add the mass to your car

L - lower the mass of your car

T - activate/deactivate forces to your car


# Made by

Ogylandy Yespagambetov - [Oga29](https://github.com/Oga29)  https://github.com/Oga29


# Music used

[Lil Jon ft. Eastside boys - Get Low](https://www.youtube.com/watch?v=DKoY1fw7yCo)
